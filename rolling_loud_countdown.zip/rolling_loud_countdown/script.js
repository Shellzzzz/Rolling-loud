// Change this to your real Rolling Loud trip/festival date.
// Format: YYYY-MM-DDTHH:MM:SS
const EVENT_DATE = '2026-11-13T15:00:00';

const daysEl = document.getElementById('days');
const hoursEl = document.getElementById('hours');
const minutesEl = document.getElementById('minutes');
const secondsEl = document.getElementById('seconds');
const messageEl = document.getElementById('message');
const loveButton = document.getElementById('loveButton');
const confetti = document.getElementById('confetti');

function pad(number) {
  return String(number).padStart(2, '0');
}

function updateCountdown() {
  const now = new Date().getTime();
  const eventTime = new Date(EVENT_DATE).getTime();
  const difference = eventTime - now;

  if (difference <= 0) {
    daysEl.textContent = '00';
    hoursEl.textContent = '00';
    minutesEl.textContent = '00';
    secondsEl.textContent = '00';
    messageEl.textContent = 'It is Rolling Loud time. Let’s go!';
    document.body.classList.add('festival-mode');
    return;
  }

  const days = Math.floor(difference / (1000 * 60 * 60 * 24));
  const hours = Math.floor((difference / (1000 * 60 * 60)) % 24);
  const minutes = Math.floor((difference / (1000 * 60)) % 60);
  const seconds = Math.floor((difference / 1000) % 60);

  daysEl.textContent = pad(days);
  hoursEl.textContent = pad(hours);
  minutesEl.textContent = pad(minutes);
  secondsEl.textContent = pad(seconds);

  messageEl.textContent = `${days} days until Orlando, beach days, festival nights, and memories together.`;
}

function launchConfetti() {
  const colors = ['#ff2bd6', '#7c3cff', '#00f7ff', '#ffe66d', '#ffffff'];

  for (let i = 0; i < 80; i++) {
    const piece = document.createElement('span');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + 'vw';
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDelay = Math.random() * 0.7 + 's';
    piece.style.transform = `rotate(${Math.random() * 360}deg)`;
    confetti.appendChild(piece);

    setTimeout(() => piece.remove(), 3600);
  }
}

loveButton.addEventListener('click', () => {
  document.body.classList.toggle('festival-mode');
  launchConfetti();
});

updateCountdown();
setInterval(updateCountdown, 1000);
