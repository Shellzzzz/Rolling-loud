# Rolling Loud Countdown

A mobile-friendly animated countdown page for Rolling Loud with Orlando, beach, and music festival vibes.

## How to edit the countdown date

Open `script.js` and change this line:

```js
const EVENT_DATE = '2026-11-13T15:00:00';
```

Use this format:

```js
YYYY-MM-DDTHH:MM:SS
```

Example:

```js
const EVENT_DATE = '2026-11-13T15:00:00';
```

## Upload to GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md`.
3. Go to **Settings** → **Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and root folder.
6. Save, then share the GitHub Pages link.
